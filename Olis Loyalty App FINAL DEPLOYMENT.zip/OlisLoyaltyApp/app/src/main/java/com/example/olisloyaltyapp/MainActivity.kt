package com.example.olisloyaltyapp

import androidx.compose.ui.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.olisloyaltyapp.ui.theme.OlisLoyaltyAppTheme
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
//import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private var showOverviewImage by mutableStateOf(false)
    private var showCardsPage by mutableStateOf(false)
    private var showFriendsPage by mutableStateOf(false)
    private var showRewardsPage by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OlisLoyaltyAppTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var selectedItem by remember { mutableStateOf(0) }
                    CircularImageWithText(
                        selectedItem = selectedItem,
                        onItemSelected = { index ->
                            selectedItem = index
                        },
                        itemFunctions = listOf(
                            ::onOverviewClicked,
                            ::onCardsClicked,
                            ::onFriendsClicked,
                            ::onRewardsClicked
                        )
                    )
                }
            }
        }
    }

    private fun onOverviewClicked() {
        showOverviewImage = true
    }

    private fun onCardsClicked() {
        showCardsPage = true
    }

    private fun onFriendsClicked() {
        showFriendsPage = true
    }

    private fun onRewardsClicked() {
        showRewardsPage = true
    }

    @Preview(showBackground = true)
    @Composable
    fun CircularImageWithTextPreview() {
        var selectedItem by remember { mutableStateOf(0) }

        OlisLoyaltyAppTheme {
            Column {
                if (showOverviewImage) {
                    // Display the custom Box with text, image, and background color
                    OverviewBox()
                }
                CircularImageWithText(
                    selectedItem = selectedItem,
                    onItemSelected = { index ->
                        selectedItem = index
                    },
                    itemFunctions = listOf(
                        ::onOverviewClicked,
                        ::onCardsClicked,
                        ::onFriendsClicked,
                        ::onRewardsClicked
                    )
                )
            }
        }
    }
}

//@Composable
//fun OverviewBox() {
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(MaterialTheme.colorScheme.background) // Set the background color to the theme's background color
////            .clickable { onClick() }, // Close the box when clicked
//    ) {
//        Column(
//            modifier = Modifier.fillMaxSize(),
//            verticalArrangement = Arrangement.Top,
//            horizontalAlignment = Alignment.Start
//        ) {
//            // Text at the top-left corner
//            Text(
//                text = "Nearby Stations >",
//                modifier = Modifier.padding(16.dp),
//                fontWeight = FontWeight.Bold,
//                color = MaterialTheme.colorScheme.onBackground // Set the text color to the theme's text color
//            )
//
//            // Image below the text
//            Image(
//                painter = painterResource(id = R.drawable.maps),
//                contentDescription = null,
//                modifier = Modifier
//                    .size(500.dp) // Adjust the size as needed
//                    .padding(15.dp)
//            )
//        }
//    }
//}


@Composable
fun OverviewBox() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0XFFE0E0E0)) // Set the background color to the theme's background color
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            // Text at the top-left corner
            Text(
                text = "Nearby Stations >",
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp),
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground // Set the text color to the theme's text color
            )

            // Image below the text without extra padding
            Image(
                painter = painterResource(id = R.drawable.maps),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp) // Adjust the size as needed
                    .padding(16.dp)
            )

            // Wrap the rows in a column to control spacing
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.Start
            ) {
                // First Row for circular image and text
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Circular image
                    Image(
                        painter = painterResource(id = R.drawable.pepe_the_frog),
                        contentDescription = null,
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .padding(15.dp),
                        contentScale = ContentScale.Crop
                    )

                    // Text
                    Text(
                        text = "Fill Up for Weekend", // Replace with your desired text
                        modifier = Modifier.padding(start = 16.dp),
                    )
                }

                // Spacer to control the space between rows
                Spacer(modifier = Modifier.height(16.dp))

                // Second Row for circular image and text
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Circular image
                    Image(
                        painter = painterResource(id = R.drawable.pepe_the_frog),
                        contentDescription = null,
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .padding(15.dp),
                        contentScale = ContentScale.Crop
                    )

                    // Text
                    Text(
                        text = "Fill up for the next weeks forecasted extreme cold weather event", // Replace with your desired text
                        modifier = Modifier.padding(start = 16.dp),
                    )
                }
            }
        }
    }
}






//@Composable
//fun CircularImageWithText() {
//    Box(
//        modifier = Modifier.fillMaxSize(),
//        contentAlignment = Alignment.TopStart
//    ) {
//        // Top right icons (statistic and notification)
//        Row(
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(16.dp),
//            horizontalArrangement = Arrangement.End,
//            verticalAlignment = Alignment.Top
//        ) {
//            Image(
//                painter = painterResource(id = R.drawable.analysis),
//                contentDescription = null, // Add appropriate content description
//                modifier = Modifier
//                    .size(60.dp)
//                    .padding(4.dp)
//            )
//
//            Spacer(modifier = Modifier.width(16.dp))
//
//            Image(
//                painter = painterResource(id = R.drawable.notification),
//                contentDescription = null, // Add appropriate content description
//                modifier = Modifier
//                    .size(50.dp)
//                    .padding(4.dp)
//            )
//        }
//
//        // Circular image and text
//        Row(
//            verticalAlignment = Alignment.CenterVertically,
//            modifier = Modifier.padding(16.dp)
//        ) {
//            // Circular image
//            Image(
//                painter = painterResource(id = R.drawable.profile),
//                contentDescription = null, // Add appropriate content description
//                modifier = Modifier
//                    .size(50.dp)
//                    .clip(CircleShape)
//                    .padding(4.dp),
//                contentScale = ContentScale.Crop
//            )
//
//            // Text
//            Text(
//                text = "Home",
//                modifier = Modifier.padding(start = 16.dp),
//            )
//        }
//    }
//}

@Composable
fun CircularImageWithText(selectedItem: Int, onItemSelected: (Int) -> Unit,
                          itemFunctions: List<() -> Unit>) {
    val items = listOf("OverView", "Cards", "Friends", "Rewards")
//    var showOverviewImage by remember { mutableStateOf(selectedItem == 0) }
//    var showCardsPage by remember { mutableStateOf(selectedItem == 0) }
//    var showFriendsPage by remember { mutableStateOf(selectedItem == 0) }

    val showOverviewImage = selectedItem == 0
    val showCardsPage = selectedItem == 1
    val showFriendsPage = selectedItem == 2
    val showRewardsPage = selectedItem == 3

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0XFFE0E0E0))
    ) {
        // Top right icons (statistic and notification)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.Top
        ) {
            Image(
                painter = painterResource(id = R.drawable.analysis),
                contentDescription = null,
                modifier = Modifier
                    .size(60.dp)
                    .padding(4.dp)
            )

//            Spacer(modifier = Modifier.width(16.dp))

            Image(
                painter = painterResource(id = R.drawable.notification),
                contentDescription = null,
                modifier = Modifier
                    .size(50.dp)
                    .padding(4.dp)
            )
        }

        // Circular image and text
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(16.dp)
        ) {
            // Circular image
            Image(
                painter = painterResource(id = R.drawable.pepe_the_frog),
                contentDescription = null,
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .padding(4.dp),
                contentScale = ContentScale.Crop
            )

            // Text
            Text(
                text = items[selectedItem],
                modifier = Modifier.padding(start = 16.dp),
            )
        }

        // Navigation bar (text-only)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { index, label ->
                Text(
                    text = label,
                    modifier = Modifier
                        .clickable {
                            onItemSelected(index)
                            itemFunctions.getOrNull(index)?.invoke()
                        }
                        .padding(16.dp),
                    style = if (index == selectedItem) {
                        TextStyle(fontWeight = FontWeight.Bold)
                    } else {
                        TextStyle(fontWeight = FontWeight.Normal)
                    },
                    color = if (index == selectedItem) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onBackground
                    },
                )
            }
        }

        // Display the custom content based on the selected item
        when {
            showOverviewImage -> OverviewBox()
            showCardsPage -> CardsPage()
            showFriendsPage -> friends_page_upgraded()
            showRewardsPage -> rewards_page()
        }
    }
}

@Preview(showBackground = true)
@Composable
fun CardsPage() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0XFFE0E0E0))
    ) {
        // Top Button
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.TopStart
        ) {
            Button(onClick = { /* Do nothing here */ }) {
                Text(
                    text = "Get card",
                    style = TextStyle(
                        color = Color.Green
                    )
                )
            }
        }

        // Placeholder for card image
        Row {
            Text(
                text = "There is suppose to be an image here. Too many issues getting it to work.",
                style = TextStyle(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal,
                    fontSize = 15.sp,
                    color = Color.Black
                )
            )
        }

        // Buttons Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.Start
        ) {
            Button(onClick = {}) {
                Text(
                    text = "Spending limit",
                    style = TextStyle(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal,
                        fontSize = 15.sp,
                        color = Color.Black
                    )
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Button(onClick = {}) {
                Text(
                    text = "Share",
                    style = TextStyle(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal,
                        fontSize = 15.sp,
                        color = Color.Black
                    )
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Button(onClick = {}) {
                Text(
                    text = "Manage",
                    style = TextStyle(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal,
                        fontSize = 15.sp,
                        color = Color.Black
                    )
                )
            }
        }

        // Transaction Header and Manage Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Transactions",
                style = TextStyle(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.Black
                )
            )
            Button(
                onClick = {}
            ) {
                Text(
                    text = "See all",
                    style = TextStyle(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal,
                        fontSize = 15.sp,
                        color = Color.Black
                    )
                )
            }
        }

        // Transaction Entry
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .background(Color.White)
                .border(1.dp, Color.Black)
        ) {
            // Use Column to separate Rows vertically
            Column {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Yesterdays transactions",
                        style = TextStyle(
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.Black
                        )
                    )
                }

                // Transaction 1
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Olis Saebraut",
                        style = TextStyle(
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.Black
                        )
                    )
                    Text(
                        text = "€41.47",
                        style = TextStyle(
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Normal,
                            fontSize = 15.sp,
                            color = Color.Black
                        )
                    )
                }

                // Transaction 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Olis Alfheimar",
                        style = TextStyle(
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.Black
                        )
                    )
                    Text(
                        text = "€30.12",
                        style = TextStyle(
                            fontFamily = FontFamily.Default,
                            fontWeight = FontWeight.Normal,
                            fontSize = 15.sp,
                            color = Color.Black
                        )
                    )
                }
            }
        }
        Button(
            onClick = { /* Do nothing here */ },
            modifier = Modifier
                .background(Color.White)
                .border(1.dp, Color.Black)
        ){
            Text(
                text = "Add to google wallet",
                style = TextStyle(
                    color = Color.Black
                )
            )
        }
        Button(
            onClick = { /* Do nothing here */ },
            modifier = Modifier
                .background(Color.White)
                .border(1.dp, Color.Black)
        ){
            Text(
                text = "Add to apple wallet",
                style = TextStyle(
                    color = Color.Black
                )
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true)
@Composable
fun friends_page_upgraded(){
    var searchQuery by remember { mutableStateOf("") }
    val names = listOf("Professor Velasco", "Ariel Raya", "Laura Reyes", "Chavey Gonzales", "Ilya Yamrokevich", "Brayan Durano")
    val filteredNames = names.filter { it.contains(searchQuery, ignoreCase = true) }

    Column {
        TextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Search Friends") }
        )

        filteredNames.forEach { name ->
            FriendRow(name)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {}
        ) {
            Text(
                text = "Add friend",
                style = TextStyle(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Bold,
                    fontSize = 21.sp,
                    color = Color.Black
                )
            )
        }
    }
}

@Composable
fun FriendRow(name: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color.Black),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = name,
            style = TextStyle(
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Normal,
                fontSize = 15.sp,
                color = Color.Black
            )
        )
        Button(
            onClick = {}
        ) {
            Text(
                text = "Share card",
                style = TextStyle(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal,
                    fontSize = 15.sp,
                    color = Color.Black
                )
            )
        }
    }
}
//123456
@Preview(showBackground = true)
@Composable
fun rewards_page(){
    // Wrapper Column
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .background(Color.Gray),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Rewards Section
        Section(title = "Rewards", buttonText = "See all") {
            // Reward items here
            RewardItem(
                description = "4% off on the next fuel refill",
                buttonText = "Use eligible payment system"
            )
            RewardItem(
                description = "4 free coffees",
                buttonText = "Use eligible payment system"
            )
        }
        //123456
        // Spacer
        Spacer(modifier = Modifier.height(3.dp))

        // Achievements Section
        Section(title = "Achievements", buttonText = "See all") {
            // Achievement items here
            RewardItem(
                description = "Full tanker.",
                buttonText = "Claim now"
            )
            RewardItem(
                description = "Birthday bonanza.",
                buttonText = "Claim now"
            )
        }
    }
}


@Composable
fun Section(title: String, buttonText: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .border(2.dp, Color.Black)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            BasicText(
                text = title,
                style = TextStyle(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal,
                    fontSize = 15.sp,
                    color = Color.Black
                )
            )
            Button(
                onClick = {}
            ) {
                BasicText(
                    text = buttonText,
                    style = TextStyle(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal,
                        fontSize = 15.sp,
                        color = Color.Green
                    )
                )
            }
        }

        // Content
        content()
    }
}

@Composable
fun RewardItem(description: String, buttonText: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        BasicText(
            text = description,
            style = TextStyle(
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = Color.Black
            )
        )
        Button(
            onClick = {}
        ) {
            BasicText(
                text = buttonText,
                style = TextStyle(
                    fontFamily = FontFamily.Default,
                    fontWeight = FontWeight.Normal,
                    fontSize = 10.sp,
                    color = Color.Green
                )
            )
        }
    }
}
